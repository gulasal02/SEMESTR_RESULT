<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>NATIYJELER</title>
</head>
<body>
<!-- partial:index.partial.html -->
    <center>
    <h1><a href="{{ url('') }}">IZGE</a></h1>
    <h1>{{$student->fullname}} ozlestiriwi. Semestr natiyjeleri</h1>
    </center>
<table border="5">
      <thead>
        <tr>
          <th>Pan ati</th>
          <th>Pan oqitiwshis</th>
          <th>Shegaraliq baqlaw</th>
          <th>Juwmaqlawshi baqlaw</th>
          <th>Natiyje</th>
          <th>Bahasi</th>    
        </tr>
      <thead>
      <tbody>
        @foreach ($results as $result)
        @if ($student->fullname == $result->student_fullname)
            <tr>
                <td>{{$result->subject_name}}</td>
                @foreach ($subjects as $subject)
                @if ($subject->name == $result->subject_name)
                    <td>{{$subject->teacher}}</td>
                @endif
                @endforeach
                <td>{{$result->border_control}}</td>
                <td>{{$result->final_control}}</td>
                <td>{{$result->result}}</td>
                @if ($result->result>=60 AND $result->result < 70)
                <td>3</td>
                @elseif ($result->result>=70 AND $result->result < 90)
                <td>4</td>
                @elseif ($result->result >= 90 AND $result->result <= 100)
                <td>5</td>
                @else
                <td>You failed the exam!</td>
                @endif
            </tr>
        @endif
        @endforeach
      </tbody>
    <table/>
<!-- partial -->
</body>
</html>