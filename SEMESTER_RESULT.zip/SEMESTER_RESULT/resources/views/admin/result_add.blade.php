<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>NÁTIYJE</title>
</head>
<body>
<!-- partial:index.partial.html -->
    <h1><a href="{{ route('result.index') }}">IZGE</a></h1>
    <h1>{{$subject->name}} paninen semestr natiyjeleri</h1>
<table border="5">
      <thead>
        <tr>
          <th>№</th>
          <th>Ati, familiyasi</th>
          <th>Baha qoyiw</th>
          <th>Ozgertiw</th>
          <th>Shegaraliq baqlaw</th>
          <th>Juwmaqlawshi baqlaw</th>
          <th>Natiyje</th>
          <th>Baha</th>    
        </tr>
      <thead>
      <tbody>
        @foreach ($students as $student)
        <tr>
          <td>{{$loop->iteration}}</td>
          <td>{{$student->fullname}}</td>
          <td>
            <form action="{{url('create_result')}}" method="POST">
                @csrf
                <input type="hidden" name="student_fullname" value="{{$student->fullname}}">
                <input type="hidden" name="subject_name" value="{{$subject->name}}">
                <button style="color: blue">Baha qoyiw</button>
            </form>
          </td>
          @foreach ($results as $result)
          @if ($result->student_fullname == $student->fullname AND $result->subject_name == $subject->name)
          <td>
            <form action="{{url('edit_result')}}" method="POST">
                @csrf
                <input type="hidden" name="student_fullname" value="{{$student->fullname}}">
                <input type="hidden" name="subject_name" value="{{$subject->name}}">
                <input type="hidden" name="id" value="{{$result->id}}">
                <button style="color: blue">Ozgertiw</button>
            </form>
          </td>
          <td>{{$result->border_control}}</td>
          <td>{{$result->final_control}}</td>
          <td>{{$result->result}}</td>
          @if ($result->result>=60 AND $result->result < 70)
          <td>3</td>
          @elseif ($result->result>=70 AND $result->result < 90)
          <td>4</td>
          @elseif ($result->result >= 90 AND $result->result <= 100)
          <td>5</td>
          @else
          <td>You failed the exam!</td>
          @endif
          @endif
          @endforeach
        </tr>
        @endforeach
      </tbody>
    <table/>
<!-- partial -->
  
</body>
</html>
