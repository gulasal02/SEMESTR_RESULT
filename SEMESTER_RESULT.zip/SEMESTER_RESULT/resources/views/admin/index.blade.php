<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>SEMESTER</title>
</head>
<body>
    <h1><a href="{{route('result.index')}}" style="color: blue">NÁTIYJELERLERDI KIRITIW</a></h1>  
    <h1><a href="{{route('student.index')}}" style="color: blue">STUDENTLERDI KIRITIW</a></h1>
    <h1><a href="{{route('subject.index')}}" style="color: blue">PÁNLERLERDI KIRITIW</a></h1>
</body>
</html>
