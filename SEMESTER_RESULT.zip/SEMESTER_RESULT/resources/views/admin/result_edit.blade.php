<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>NÁTIYJE</title>
</head>
<body>
<!-- partial:index.partial.html -->
    <h1><a href="{{route('result.show', $subject[0]->id)}}">IZGE</a></h1>
    <h1>{{$student_fullname}} {{$subject_name}} <br> paninen semestr natiyjeleri</h1>
    <form action="{{ route('result.update', $result->id) }}" method="POST">
      @csrf
      @method('PUT')
      <label for="">1. Shegaraliq bahani ozgertiw<br>
        (Keminde 30 ball boliwi kerek)
      </label><br><br>
      <input type="number" name="border_control" value="{{$result->border_control}}"><br><br>
      <label for="">2. Juwmaqlawshi bahani ozgertiw...<br>
        (Keminde 30 ball boliwi kerek)
      </label><br><br>
      <input type="number" name="final_control" value="{{$result->final_control}}"><br><br>
      <input type="hidden" name="student_fullname" value="{{$student_fullname}}">
      <input type="hidden" name="subject_name" value="{{$subject_name}}">
      <input type="hidden" name="status" value="1">
      <button>OZGERTIW</button>
    </form>
<!-- partial -->
</body>
</html>
