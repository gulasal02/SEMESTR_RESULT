<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>NÁTIYJELER</title>
</head>
<body>
<!-- partial:index.partial.html -->
    <h1><a href="{{ url('admins') }}">IZGE</a></h1>
    <h1>Student ozlestiriwi. Semestr natiyjeleri</h1>
<table border="5">
      <thead>
        <tr>
          <th>№</th>
          <th>Pan ati</th>
          <th>Baha qoyiw</th>
        </tr>
      <thead>
      <tbody>
        @foreach ($subjects as $subject)
        <tr>
          <td>{{$loop->iteration}}</td>
          <td>{{$subject->name}}</td>
          <td>
            <form action="{{route('result.show', $subject->id)}}" method="GET">
                <button style="color: blue">Baha qoyiw</button>
            </form>
          </td>
        </tr>
        @endforeach
      </tbody>
    <table/>
<!-- partial -->
  
</body>
</html>
