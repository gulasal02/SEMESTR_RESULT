<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>NATIYJE</title>
</head>
<body>
<!-- partial:index.partial.html -->
    <h1><a href="{{route('result.show', $subject[0]->id)}}">IZGE</a></h1>
    <h1>{{$student_fullname}} {{$subject_name}} <br> paninen semestr natiyjelerin qoyiw</h1>
    <form action="{{ route('result.store') }}" method="POST">
      @csrf
      <label for="" style="color: blue">1. Shegaraliq bahasin qoyiw...<br>
        (Keminde 30 ball boliwi kerek)
      </label><br><br>
      <input type="number" name="border_control" required><br><br>
      <label for="" style="color: blue">2. Juwmaqlawshi bahasin qoyiw<br>
        (Keminde 30 ball boliwi kerek)
      </label><br><br>
      <input type="number" name="final_control" required><br><br>
      <input type="hidden" name="student_fullname" value="{{$student_fullname}}">
      <input type="hidden" name="subject_name" value="{{$subject_name}}">
      <input type="hidden" name="status" value="1">
      <button style="color: blue">QOSÍW</button>
    </form>
<!-- partial -->
</body>
</html>
