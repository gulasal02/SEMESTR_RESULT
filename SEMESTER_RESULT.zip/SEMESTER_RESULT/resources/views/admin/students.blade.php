<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>STUDENTLER</title>
</head>
<body>
<!-- partial:index.partial.html -->
    <h1><a href="{{ url('admins') }}">IZGE</a></h1>
<table border="5">
      <thead>
        <tr>
          <th>№</th>
          <th>Ati, familiyasi</th>
          <th>Logini</th>
          <th>Paroli</th>
          <th>Ozgertiw</th>
          <th>Oshiriw</th>
        </tr>
      <thead>
      <tbody>
        @foreach ($students as $student)
        <tr>
          <td>{{$loop->iteration}}</td>
          <td>{{$student->fullname}}</td>
          <td>{{$student->login}}</td>
          <td>{{$student->password}}</td>
          <td><a href="{{route('student.edit', $student->id)}}" style="size: 20ch">EDIT</a></td>
          <td>
            <form action="{{route('student.destroy', $student->id)}}" method="POST">
                @csrf
                @method('DELETE')
                <button style="color: blue">DELETE</button>
            </form>
          </td>
        </tr>
        @endforeach
      </tbody>
    <table/>
    <h1>Studentlerdin dizimi</h1>
    <h2 style="color: red">Student qosiw</h2>
    <form action="{{route('student.store')}}" method="POST">
        @csrf
        <label for="">1.Student toliq ati,familiyasin kiritin</label><br><br>
        <input type="text" name="fullname" required><br><br>
        <label for="">2.Student toliq loginin kiritin</label><br><br>
        <input type="text" name="login" required><br><br>
        <label for="">3.Student toliq parolin kiritin</label><br><br>
        <input type="text" name="password" required><br><br>
        <button style="color: blue">QOSIW</button>
    </form><br>
<!-- partial -->
  
</body>
</html>
