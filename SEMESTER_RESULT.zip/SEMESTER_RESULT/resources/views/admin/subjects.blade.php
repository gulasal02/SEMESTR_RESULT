<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>PANLER</title>
</head>
<body>
<!-- partial:index.partial.html -->
    <h1><a href="{{ url('admins') }}">IZGE</a></h1>
    <table border="5">
      <thead>
        <tr>
          <th>№</th>
          <th>Pan ati</th>
          <th>Pan mugallimi</th>
          <th>Ozgertiw</th>
          <th>Oshiriw</th>
        </tr>
      <thead>
      <tbody>
        @foreach ($subjects as $subject)
        <tr>
          <td>{{$loop->iteration}}</td>
          <td>{{$subject->name}}</td>
          <td>{{$subject->teacher}}</td>
          <td><a href="{{route('subject.edit', $subject->id)}}" style="size: 20ch">EDIT</a></td>
          <td>
            <form action="{{route('subject.destroy', $subject->id)}}" method="POST">
                @csrf
                @method('DELETE')
                <button style="color: blue">DELETE</button>
            </form>
          </td>
        </tr>
        @endforeach
      </tbody>
    <table/>
    <h1>PANLERDI KIRITIW</h1>
    <h2 style="color: red">PANLERDI QOSIW</h2>
    <form action="{{route('subject.store')}}" method="POST">
        @csrf
        <label for="">1.Pandi kiritin</label><br><br>
        <input type="text" name="name" required><br><br>
        <label for="">2.Pan mugallimin kiritin</label><br><br>
        <input type="text" name="teacher" required><br><br>
        <button style="color: blue">QOSÍW</button>
    </form><br>
    </center>
<!-- partial -->
  
</body>
</html>