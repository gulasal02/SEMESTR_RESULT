<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>PÁNLER</title>
</head>
<body>
<!-- partial:index.partial.html -->
    <h1><a href="{{ url('admins') }}">IZGE</a></h1>
    <h1>Bolip otetugin panler</h1>
    <h2 style="color: red">Pandi ozgertiw</h2>
    <form action="{{route('subject.update', $subject->id)}}" method="POST">
        @csrf
        @method('PUT')
        <label for="">1.Pan atin ozgertin</label><br><br>
        <input type="text" name="name" value="{{$subject->name}}"><br><br>
        <label for="">2.Pan oqitiwshisin kiritin</label><br><br>
        <input type="text" name="teacher" value="{{$subject->teacher}}"><br><br>
        <button style="color: blue">OZGERTIW</button>
    </form><br>
<!-- partial -->
  
</body>
</html>