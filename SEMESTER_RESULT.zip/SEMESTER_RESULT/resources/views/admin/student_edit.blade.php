<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>STUDENTLER</title>
</head>
<body>
<!-- partial:index.partial.html -->
    <h1><a href="{{ route('student.index') }}">IZGE</a></h1>
    <h1 style="color: red">Student ozgertiw</h1>
    <form action="{{route('student.update', $student->id)}}" method="POST">
        @csrf
        @method('PUT')
        <label for="">1.Student ati, familiyasin ozgertiw</label><br><br>
        <input type="text" name="fullname" value="{{$student->fullname}}"><br><br>
        <label for="">2.Student  ozgertiw</label><br><br>
        <input type="text" name="login" value="{{$student->login}}"><br><br>
        <label for="">3.Student ati, familiyasin ozgertiw</label><br><br>
        <input type="text" name="password" VALUE="{{$student->password}}"><br><br>
        <button style="color: blue">OZGERTIW</button>
    </form><br>
<!-- partial -->
  
</body>
</html>
