<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>results</title>
  <link rel="stylesheet" href="<?php echo e(asset("./table/style.css")); ?>">
</head>
<body>
<!-- partial:index.partial.html -->
    <center>
    <h1><a href="<?php echo e(url('')); ?>">Back</a></h1>
    <h1><?php echo e($student->fullname); ?>'s semester results in all subjects</h1>
    </center>
<table>
      <thead>
        <tr>
          <th>Subject name</th>
          <th>Subject teacher</th>
          <th>Border control</th>
          <th>Final control</th>
          <th>Result</th>
          <th>Grade</th>    
        </tr>
      <thead>
      <tbody>
        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($student->fullname == $result->student_fullname): ?>
            <tr>
                <td><?php echo e($result->subject_name); ?></td>
                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($subject->name == $result->subject_name): ?>
                    <td><?php echo e($subject->teacher); ?></td>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($result->border_control); ?></td>
                <td><?php echo e($result->final_control); ?></td>
                <td><?php echo e($result->result); ?></td>
                <?php if($result->result>=60 AND $result->result < 70): ?>
                <td>3</td>
                <?php elseif($result->result>=70 AND $result->result < 90): ?>
                <td>4</td>
                <?php elseif($result->result >= 90 AND $result->result <= 100): ?>
                <td>5</td>
                <?php else: ?>
                <td>You failed the exam!</td>
                <?php endif; ?>
            </tr>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    <table/>
      
    <blockquote> Results System </blockquote>
<!-- partial -->
  
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\VEDMOST\resources\views/index.blade.php ENDPATH**/ ?>