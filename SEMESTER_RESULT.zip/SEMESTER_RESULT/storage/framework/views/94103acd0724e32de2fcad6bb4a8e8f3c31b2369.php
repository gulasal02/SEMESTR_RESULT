<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>results</title>
  <link rel="stylesheet" href="<?php echo e(asset("./table/style.css")); ?>">
</head>
<body>
<!-- partial:index.partial.html -->
    <center>
    <h1><a href="<?php echo e(route('result.show', $subject[0]->id)); ?>">Back</a></h1>
    <h1>Add the <?php echo e($student_fullname); ?>'s control scores in <?php echo e($subject_name); ?></h1>
    <form action="<?php echo e(route('result.store')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <label for="">1. Enter the border control's score...<br>
        (Must be above 30 score)
      </label><br><br>
      <input type="number" name="border_control" placeholder="border_control" required><br><br>
      <label for="">2. Enter the final control's score...<br>
        (Must be above 30 score)
      </label><br><br>
      <input type="number" name="final_control" placeholder="final_control" required><br><br>
      <input type="hidden" name="student_fullname" value="<?php echo e($student_fullname); ?>">
      <input type="hidden" name="subject_name" value="<?php echo e($subject_name); ?>">
      <input type="hidden" name="status" value="1">
      <button>CREATE</button>
    </form>
    </center>
  
<!-- partial -->
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\VEDMOST\resources\views/admin/result_create.blade.php ENDPATH**/ ?>