<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>registraciya</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" type="text/css" href="css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <!-- owl stylesheets --> 
      <link rel="stylesheet" href="css/owl.carousel.min.css">
      <link rel="stylesheet" href="css/owl.theme.default.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
   </head>
   <body>
      
      <!-- contact section start -->
      <form action="<?php echo e(url('registraciya')); ?>" method="POST">
         <?php echo csrf_field(); ?>
         <div class="contact_section layout_padding">
            <div class="container">
               <div class="row">
                  <div class="col-md-6">
                     <h2>BERDAQ NOMIDAGI QORAQALPOQ BAVLAT UNIVERSITETINING MATEMATIKA FAKULTETI 3-I KOMPYUTER ILIMLARI
                        VA DASTURLASH TEXNOLOGIYALARI GURUHI
                     </h2>
                     <center><div class="image_9"><img src="images/qmu.jpg" width="220" height="220"></div></center>
                  </div> 
                  <div class="col-md-6">
                     <h2>Kirish uchun login va parolingizni kiriting!</h2>
                     <div class="mail_sectin">
                        <label class="email-bt" style="color: black" for="">Loginingizni kiriting...</label>
                        <input type="text" class="email-bt" style="color: blue" placeholder="Login..........................................." name="login" required>
                        <label class="email-bt" style="color: black" for="">Parolingizni kiriting...</label>
                        <input type="text" class="email-bt" style="color: blue" placeholder="Parol..........................................." name="password" required>
                        <input type="submit" value="Kirish" class="email-bt" style="color: blue">
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </form>
      <!-- contact section end -->
     
      <!-- Javascript files-->
      <script src="js/jquery.min.js"></script>
      <script src="js/popper.min.js"></script>
      <script src="js/bootstrap.bundle.min.js"></script>
      <script src="js/jquery-3.0.0.min.js"></script>
      <script src="js/plugin.js"></script>
      <!-- sidebar -->
      <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="js/custom.js"></script>
      <!-- javascript --> 
      <script src="js/owl.carousel.js"></script>
      <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>    
   </body>
</html><?php /**PATH C:\MAMP\htdocs\VEDMOST\resources\views/registraciya.blade.php ENDPATH**/ ?>