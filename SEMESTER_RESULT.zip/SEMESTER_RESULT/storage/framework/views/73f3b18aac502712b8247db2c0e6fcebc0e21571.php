<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>NATIYJELER</title>
</head>
<body>
<!-- partial:index.partial.html -->
    <center>
    <h1><a href="<?php echo e(url('')); ?>">IZGE</a></h1>
    <h1><?php echo e($student->fullname); ?> ozlestiriwi. Semestr natiyjeleri</h1>
    </center>
<table border="5">
      <thead>
        <tr>
          <th>Pan ati</th>
          <th>Pan oqitiwshis</th>
          <th>Shegaraliq baqlaw</th>
          <th>Juwmaqlawshi baqlaw</th>
          <th>Natiyje</th>
          <th>Bahasi</th>    
        </tr>
      <thead>
      <tbody>
        <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($student->fullname == $result->student_fullname): ?>
            <tr>
                <td><?php echo e($result->subject_name); ?></td>
                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($subject->name == $result->subject_name): ?>
                    <td><?php echo e($subject->teacher); ?></td>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <td><?php echo e($result->border_control); ?></td>
                <td><?php echo e($result->final_control); ?></td>
                <td><?php echo e($result->result); ?></td>
                <?php if($result->result>=60 AND $result->result < 70): ?>
                <td>3</td>
                <?php elseif($result->result>=70 AND $result->result < 90): ?>
                <td>4</td>
                <?php elseif($result->result >= 90 AND $result->result <= 100): ?>
                <td>5</td>
                <?php else: ?>
                <td>You failed the exam!</td>
                <?php endif; ?>
            </tr>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    <table/>
<!-- partial -->
</body>
</html><?php /**PATH C:\MAMP\htdocs\SEMESTER_RESULT\resources\views/index.blade.php ENDPATH**/ ?>