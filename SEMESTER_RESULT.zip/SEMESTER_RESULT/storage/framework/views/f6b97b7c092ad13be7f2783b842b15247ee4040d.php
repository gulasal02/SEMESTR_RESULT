<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>vedmost</title>
  <link rel="stylesheet" href="./table/style.css">
</head>
<body>
    <h1><a href="<?php echo e(route('student.index')); ?>" style="color: red">Students</a></h1>
    <h1><a href="<?php echo e(route('subject.index')); ?>" style="color: black">Subjects</a></h1>
    <h1><a href="<?php echo e(route('result.index')); ?>">Results</a></h1>  
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\VEDMOST\resources\views/admin/index.blade.php ENDPATH**/ ?>