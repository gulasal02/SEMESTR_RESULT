<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>SEMESTR</title>
  <link rel="stylesheet" href="./table/style.css">
</head>
<body>
    <h1><a href="<?php echo e(route('student.index')); ?>" style="color: green">STUDENTLER</a></h1>
    <h1><a href="<?php echo e(route('subject.index')); ?>" style="color: black">PÁNLER</a></h1>
    <h1><a href="<?php echo e(route('result.index')); ?>">NÁTIYJELER</a></h1>  
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\Student_Semestr\resources\views/admin/index.blade.php ENDPATH**/ ?>