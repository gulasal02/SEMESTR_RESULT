<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>subjects</title>
  <link rel="stylesheet" href="./table/style.css">
</head>
<body>
<!-- partial:index.partial.html -->
    <center>
    <h1><a href="<?php echo e(url('admins')); ?>">Back</a></h1>
    <h1>System of sciences</h1>
    <h2 style="color: red">Add subjects</h2>
    <form action="<?php echo e(route('subject.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="">1.Write the subject's name...</label><br><br>
        <input type="text" name="name" placeholder="name...................................." required><br><br>
        <label for="">2.Write the subject's teacher...</label><br><br>
        <input type="text" name="teacher" placeholder="teacher...................................." required><br><br>
        <button style="color: blue">CREATE</button>
    </form><br>
    </center>
<table>
      <thead>
        <tr>
          <th>№</th>
          <th>Name</th>
          <th>Teacher</th>
          <th>Edit</th>
          <th>Delete</th>
        </tr>
      <thead>
      <tbody>
        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <td><?php echo e($subject->name); ?></td>
          <td><?php echo e($subject->teacher); ?></td>
          <td><a href="<?php echo e(route('subject.edit', $subject->id)); ?>" style="size: 20ch">EDIT</a></td>
          <td>
            <form action="<?php echo e(route('subject.destroy', $subject->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button style="color: blue">DELETE</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    <table/>
      
    <blockquote> System of sciences </blockquote>
<!-- partial -->
  
</body>
</html><?php /**PATH C:\MAMP\htdocs\VEDMOST\resources\views/admin/subjects.blade.php ENDPATH**/ ?>