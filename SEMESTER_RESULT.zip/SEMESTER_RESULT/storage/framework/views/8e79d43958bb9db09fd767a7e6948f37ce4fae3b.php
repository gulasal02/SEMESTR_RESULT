<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>NÁTIYJE</title>
  <link rel="stylesheet" href="<?php echo e(asset("./table/style.css")); ?>">
</head>
<body>
<!-- partial:index.partial.html -->
    <center>
    <h1><a href="<?php echo e(route('result.index')); ?>">ARQAǴA</a></h1>
    <h1><?php echo e($subject->name); ?> páninen semestr nátiyjeleri</h1>
    </center>
<table>
      <thead>
        <tr>
          <th>№</th>
          <th>ATÍ,FAMILIYASÍ</th>
          <th>BAHALAW</th>
          <th>ÓZGERTIW</th>
          <th>SHEGARALÍQ BAQLAW</th>
          <th>JUWMAQLAWSHÍ BAQLAW</th>
          <th>NÁTIYJE</th>
          <th>BAHA</th>    
        </tr>
      <thead>
      <tbody>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <td><?php echo e($student->fullname); ?></td>
          <td>
            <form action="<?php echo e(url('create_result')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="student_fullname" value="<?php echo e($student->fullname); ?>">
                <input type="hidden" name="subject_name" value="<?php echo e($subject->name); ?>">
                <button style="color: blue">BAHALAW</button>
            </form>
          </td>
          <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($result->student_fullname == $student->fullname AND $result->subject_name == $subject->name): ?>
          <td>
            <form action="<?php echo e(url('edit_result')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="student_fullname" value="<?php echo e($student->fullname); ?>">
                <input type="hidden" name="subject_name" value="<?php echo e($subject->name); ?>">
                <input type="hidden" name="id" value="<?php echo e($result->id); ?>">
                <button style="color: blue">ÓZGERTIW</button>
            </form>
          </td>
          <td><?php echo e($result->border_control); ?></td>
          <td><?php echo e($result->final_control); ?></td>
          <td><?php echo e($result->result); ?></td>
          <?php if($result->result>=60 AND $result->result < 70): ?>
          <td>3</td>
          <?php elseif($result->result>=70 AND $result->result < 90): ?>
          <td>4</td>
          <?php elseif($result->result >= 90 AND $result->result <= 100): ?>
          <td>5</td>
          <?php else: ?>
          <td>You failed the exam!</td>
          <?php endif; ?>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    <table/>
      
    <blockquote> SEMESTR NÁTIYJELERI </blockquote>
<!-- partial -->
  
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\Student_Semestr\resources\views/admin/result_add.blade.php ENDPATH**/ ?>