<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>results</title>
</head>
<body>
<!-- partial:index.partial.html -->
    <center>
    <h1><a href="<?php echo e(route('result.show', $subject[0]->id)); ?>">IZGE</a></h1>
    <h1>Ozgertildi!</h1>
    </center>
<!-- partial -->
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\SEMESTER_RESULT\resources\views/admin/result_updated.blade.php ENDPATH**/ ?>