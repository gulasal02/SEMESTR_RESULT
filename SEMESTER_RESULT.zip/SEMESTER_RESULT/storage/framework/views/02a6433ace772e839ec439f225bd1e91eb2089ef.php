<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>admin</title>
  <link rel="stylesheet" href="./table/style.css">
</head>
<body>
    <h1>XUSH KELIBSIZ!</h1>
    <h2><a href="<?php echo e(url('admins')); ?>">TA'LIM MUASSASALARIDA<br> O'QUV JARAYONI NAZORATI.<br>VEDMOST TIZIMI</a></h2>
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\VEDMOST\resources\views/admin/admin.blade.php ENDPATH**/ ?>