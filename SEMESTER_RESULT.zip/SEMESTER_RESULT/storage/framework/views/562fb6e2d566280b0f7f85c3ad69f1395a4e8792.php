<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>STUDENTLER</title>
  <link rel="stylesheet" href="<?php echo e(asset("./table/style.css")); ?>">
</head>
<body>
<!-- partial:index.partial.html -->
    <center>
    <h1><a href="<?php echo e(route('student.index')); ?>">ARQAǴA</a></h1>
    <h1 style="color: red">STUDENT ÓZGERTIW</h1>
    <form action="<?php echo e(route('student.update', $student->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label for="">1.STUDENT ATÍ FAMILIYASÍN ÓZGERTIW...</label><br><br>
        <input type="text" name="fullname" value="<?php echo e($student->fullname); ?>"><br><br>
        <label for="">2.STUDENT LOGININ ÓZGERTIW...</label><br><br>
        <input type="text" name="login" value="<?php echo e($student->login); ?>"><br><br>
        <label for="">3.STUDENT PAROLIN ÓZGERTIW...</label><br><br>
        <input type="text" name="password" VALUE="<?php echo e($student->password); ?>"><br><br>
        <button style="color: blue">ÓZGERTIW</button>
    </form><br>
    </center>

<!-- partial -->
  
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\Student_Semestr\resources\views/admin/student_edit.blade.php ENDPATH**/ ?>