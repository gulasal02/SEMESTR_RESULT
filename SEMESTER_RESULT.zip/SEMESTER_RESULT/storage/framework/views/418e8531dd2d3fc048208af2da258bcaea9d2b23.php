<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>ADMIN</title>
</head>
<body>
    <h1>ASSALAWMA ALEYKUM. ADMIN PANEL</h1>
    <h2><a href="<?php echo e(url('admins')); ?>">STUDENTLERDIN OZLESTIRIWI.<br> SEMESTR NATIYJELERIN QOYIW</a></h2>
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\SEMESTER_RESULT\resources\views/admin/admin.blade.php ENDPATH**/ ?>