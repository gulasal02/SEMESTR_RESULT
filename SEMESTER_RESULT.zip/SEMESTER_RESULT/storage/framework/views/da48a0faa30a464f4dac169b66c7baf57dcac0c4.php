<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>results</title>
  <link rel="stylesheet" href="<?php echo e(asset("./table/style.css")); ?>">
</head>
<body>
<!-- partial:index.partial.html -->
    <center>
    <h1><a href="<?php echo e(route('result.show', $subject[0]->id)); ?>">Back</a></h1>
    <h1>Add the <?php echo e($student_fullname); ?>'s control scores in <?php echo e($subject_name); ?></h1>
    <form action="<?php echo e(route('result.update', $result->id)); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
      <label for="">1. Edit the border control's score...<br>
        (Must be above 30 score)
      </label><br><br>
      <input type="number" name="border_control" value="<?php echo e($result->border_control); ?>"><br><br>
      <label for="">2. Edit the final control's score...<br>
        (Must be above 30 score)
      </label><br><br>
      <input type="number" name="final_control" value="<?php echo e($result->final_control); ?>"><br><br>
      <input type="hidden" name="student_fullname" value="<?php echo e($student_fullname); ?>">
      <input type="hidden" name="subject_name" value="<?php echo e($subject_name); ?>">
      <input type="hidden" name="status" value="1">
      <button>EDIT</button>
    </form>
    </center>
  
<!-- partial -->
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\VEDMOST\resources\views/admin/result_edit.blade.php ENDPATH**/ ?>