<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>STUDENTLER</title>
  <link rel="stylesheet" href="./table/style.css">
</head>
<body>
<!-- partial:index.partial.html -->
    <center>
    <h1><a href="<?php echo e(url('admins')); ?>">ARQAǴA</a></h1>
    <h1>STUDENTLER DIZIMI</h1>
    <h2 style="color: red">STUDENT QOSÍW</h2>
    <form action="<?php echo e(route('student.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="">1.STUDENT TOLÍQ ATÍN KIRITIŃ...</label><br><br>
        <input type="text" name="fullname" placeholder="ATÍ, FAMILIYA..............................." required><br><br>
        <label for="">2.STUDENT LOGININ KIRITIŃ...</label><br><br>
        <input type="text" name="login" placeholder="LOGIN.................................." required><br><br>
        <label for="">3.STUDENT PAROLIN KIRITIŃ...</label><br><br>
        <input type="text" name="password" placeholder="PAROL..............................." required><br><br>
        <button style="color: blue">QOSÍW</button>
    </form><br>
    </center>
<table>
      <thead>
        <tr>
          <th>№</th>
          <th>ATÍ, FAMILIYASÍ</th>
          <th>LOGIN</th>
          <th>PAROL</th>
          <th>ÓZGERTIW</th>
          <th>ÓSHIRIW</th>
        </tr>
      <thead>
      <tbody>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <td><?php echo e($student->fullname); ?></td>
          <td><?php echo e($student->login); ?></td>
          <td><?php echo e($student->password); ?></td>
          <td><a href="<?php echo e(route('student.edit', $student->id)); ?>" style="size: 20ch">EDIT</a></td>
          <td>
            <form action="<?php echo e(route('student.destroy', $student->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button style="color: blue">DELETE</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    <table/>
      
    <blockquote> STUDENTLER DIZIMI </blockquote>
<!-- partial -->
  
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\Student_Semestr\resources\views/admin/students.blade.php ENDPATH**/ ?>