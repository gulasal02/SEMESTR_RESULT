<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>NÁTIYJELER</title>
</head>
<body>
<!-- partial:index.partial.html -->
    <h1><a href="<?php echo e(url('admins')); ?>">IZGE</a></h1>
    <h1>Student ozlestiriwi. Semestr natiyjeleri</h1>
<table border="5">
      <thead>
        <tr>
          <th>№</th>
          <th>Pan ati</th>
          <th>Baha qoyiw</th>
        </tr>
      <thead>
      <tbody>
        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <td><?php echo e($subject->name); ?></td>
          <td>
            <form action="<?php echo e(route('result.show', $subject->id)); ?>" method="GET">
                <button style="color: blue">Baha qoyiw</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    <table/>
<!-- partial -->
  
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\SEMESTER_RESULT\resources\views/admin/results.blade.php ENDPATH**/ ?>