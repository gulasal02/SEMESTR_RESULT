<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>subjects</title>
  <link rel="stylesheet" href="<?php echo e(asset("./table/style.css")); ?>">
</head>
<body>
<!-- partial:index.partial.html -->
    <center>
    <h1><a href="<?php echo e(url('admins')); ?>">ARQAǴA</a></h1>
    <h1>BOLÍP ÓTETUǴÍN SABAQLÍQLAR</h1>
    <h2 style="color: red">PÁNLERDI ÓZGERTIŃ</h2>
    <form action="<?php echo e(route('subject.update', $subject->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label for="">1.PÁN ATÍN ÓZGERTIŃ...</label><br><br>
        <input type="text" name="name" value="<?php echo e($subject->name); ?>"><br><br>
        <label for="">2.PÁN MUǴALLIMIN ÓZGERTIŃ...</label><br><br>
        <input type="text" name="teacher" value="<?php echo e($subject->teacher); ?>"><br><br>
        <button style="color: blue">ÓZGERTIW</button>
    </form><br>
    </center>
<!-- partial -->
  
</body>
</html><?php /**PATH C:\MAMP\htdocs\Student_Semestr\resources\views/admin/subject_edit.blade.php ENDPATH**/ ?>