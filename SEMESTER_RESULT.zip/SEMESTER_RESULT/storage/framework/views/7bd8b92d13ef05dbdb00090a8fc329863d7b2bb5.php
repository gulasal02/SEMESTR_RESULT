<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>SEMESTER</title>
</head>
<body>
    <h1><a href="<?php echo e(route('result.index')); ?>" style="color: blue">NÁTIYJELERLERDI KIRITIW</a></h1>  
    <h1><a href="<?php echo e(route('student.index')); ?>" style="color: blue">STUDENTLERDI KIRITIW</a></h1>
    <h1><a href="<?php echo e(route('subject.index')); ?>" style="color: blue">PÁNLERLERDI KIRITIW</a></h1>
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\SEMESTER_RESULT\resources\views/admin/index.blade.php ENDPATH**/ ?>