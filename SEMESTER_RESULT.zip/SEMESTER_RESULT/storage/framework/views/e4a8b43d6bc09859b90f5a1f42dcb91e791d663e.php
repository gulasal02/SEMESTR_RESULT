<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>PÁNLER</title>
</head>
<body>
<!-- partial:index.partial.html -->
    <h1><a href="<?php echo e(url('admins')); ?>">IZGE</a></h1>
    <h1>Bolip otetugin panler</h1>
    <h2 style="color: red">Pandi ozgertiw</h2>
    <form action="<?php echo e(route('subject.update', $subject->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label for="">1.Pan atin ozgertin</label><br><br>
        <input type="text" name="name" value="<?php echo e($subject->name); ?>"><br><br>
        <label for="">2.Pan oqitiwshisin kiritin</label><br><br>
        <input type="text" name="teacher" value="<?php echo e($subject->teacher); ?>"><br><br>
        <button style="color: blue">OZGERTIW</button>
    </form><br>
<!-- partial -->
  
</body>
</html><?php /**PATH C:\MAMP\htdocs\SEMESTER_RESULT\resources\views/admin/subject_edit.blade.php ENDPATH**/ ?>