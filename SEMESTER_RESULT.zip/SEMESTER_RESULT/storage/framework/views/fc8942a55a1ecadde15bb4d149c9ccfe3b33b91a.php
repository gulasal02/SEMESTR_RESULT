<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>ADMIN</title>
  <link rel="stylesheet" href="./table/style.css">
</head>
<body>
    <h1>XOSH KELDIŃIZ!</h1>
    <h2><a href="<?php echo e(url('admins')); ?>">STUDENTLERDIŃ ÓZLESTIRIWI.<br> SEMESTR NÁTIYJELERI</a></h2>
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\Student_Semestr\resources\views/admin/admin.blade.php ENDPATH**/ ?>