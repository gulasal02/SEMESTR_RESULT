<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>STUDENTLER</title>
</head>
<body>
<!-- partial:index.partial.html -->
    <h1><a href="<?php echo e(url('admins')); ?>">IZGE</a></h1>
<table border="5">
      <thead>
        <tr>
          <th>№</th>
          <th>Ati, familiyasi</th>
          <th>Logini</th>
          <th>Paroli</th>
          <th>Ozgertiw</th>
          <th>Oshiriw</th>
        </tr>
      <thead>
      <tbody>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <td><?php echo e($student->fullname); ?></td>
          <td><?php echo e($student->login); ?></td>
          <td><?php echo e($student->password); ?></td>
          <td><a href="<?php echo e(route('student.edit', $student->id)); ?>" style="size: 20ch">EDIT</a></td>
          <td>
            <form action="<?php echo e(route('student.destroy', $student->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button style="color: blue">DELETE</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    <table/>
    <h1>Studentlerdin dizimi</h1>
    <h2 style="color: red">Student qosiw</h2>
    <form action="<?php echo e(route('student.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="">1.Student toliq ati,familiyasin kiritin</label><br><br>
        <input type="text" name="fullname" required><br><br>
        <label for="">2.Student toliq loginin kiritin</label><br><br>
        <input type="text" name="login" required><br><br>
        <label for="">3.Student toliq parolin kiritin</label><br><br>
        <input type="text" name="password" required><br><br>
        <button style="color: blue">QOSIW</button>
    </form><br>
<!-- partial -->
  
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\SEMESTER_RESULT\resources\views/admin/students.blade.php ENDPATH**/ ?>