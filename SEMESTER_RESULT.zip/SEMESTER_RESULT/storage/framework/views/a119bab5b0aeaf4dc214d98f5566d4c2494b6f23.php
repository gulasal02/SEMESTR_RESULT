<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>NÁTIYJE</title>
</head>
<body>
<!-- partial:index.partial.html -->
    <h1><a href="<?php echo e(route('result.index')); ?>">IZGE</a></h1>
    <h1><?php echo e($subject->name); ?> paninen semestr natiyjeleri</h1>
<table border="5">
      <thead>
        <tr>
          <th>№</th>
          <th>Ati, familiyasi</th>
          <th>Baha qoyiw</th>
          <th>Ozgertiw</th>
          <th>Shegaraliq baqlaw</th>
          <th>Juwmaqlawshi baqlaw</th>
          <th>Natiyje</th>
          <th>Baha</th>    
        </tr>
      <thead>
      <tbody>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <td><?php echo e($student->fullname); ?></td>
          <td>
            <form action="<?php echo e(url('create_result')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="student_fullname" value="<?php echo e($student->fullname); ?>">
                <input type="hidden" name="subject_name" value="<?php echo e($subject->name); ?>">
                <button style="color: blue">Baha qoyiw</button>
            </form>
          </td>
          <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($result->student_fullname == $student->fullname AND $result->subject_name == $subject->name): ?>
          <td>
            <form action="<?php echo e(url('edit_result')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="student_fullname" value="<?php echo e($student->fullname); ?>">
                <input type="hidden" name="subject_name" value="<?php echo e($subject->name); ?>">
                <input type="hidden" name="id" value="<?php echo e($result->id); ?>">
                <button style="color: blue">Ozgertiw</button>
            </form>
          </td>
          <td><?php echo e($result->border_control); ?></td>
          <td><?php echo e($result->final_control); ?></td>
          <td><?php echo e($result->result); ?></td>
          <?php if($result->result>=60 AND $result->result < 70): ?>
          <td>3</td>
          <?php elseif($result->result>=70 AND $result->result < 90): ?>
          <td>4</td>
          <?php elseif($result->result >= 90 AND $result->result <= 100): ?>
          <td>5</td>
          <?php else: ?>
          <td>You failed the exam!</td>
          <?php endif; ?>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    <table/>
<!-- partial -->
  
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\SEMESTER_RESULT\resources\views/admin/result_add.blade.php ENDPATH**/ ?>