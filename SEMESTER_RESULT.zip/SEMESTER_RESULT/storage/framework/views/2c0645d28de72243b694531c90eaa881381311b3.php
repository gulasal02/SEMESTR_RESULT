<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>results</title>
  <link rel="stylesheet" href="<?php echo e(asset("./table/style.css")); ?>">
</head>
<body>
<!-- partial:index.partial.html -->
    <center>
    <h1><a href="<?php echo e(route('result.show', $subject[0]->id)); ?>">ARQAǴA</a></h1>
    <h1>ÓZGERTILDI!</h1>
    </center>
<!-- partial -->
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\Student_Semestr\resources\views/admin/result_updated.blade.php ENDPATH**/ ?>