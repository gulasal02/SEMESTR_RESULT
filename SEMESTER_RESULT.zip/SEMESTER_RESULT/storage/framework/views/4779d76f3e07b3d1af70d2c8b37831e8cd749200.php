<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>PÁNLER</title>
  <link rel="stylesheet" href="./table/style.css">
</head>
<body>
<!-- partial:index.partial.html -->
    <center>
    <h1><a href="<?php echo e(url('admins')); ?>">ARQAǴA</a></h1>
    <h1>BOLÍP ÓTETUǴÍN SABAQLÍQLAR</h1>
    <h2 style="color: red">PÁNLERDI QOSÍW</h2>
    <form action="<?php echo e(route('subject.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="">1.PÁN ATÍN KIRITIŃ...</label><br><br>
        <input type="text" name="name" placeholder="ATÍ...................................." required><br><br>
        <label for="">2.PÁN OQÍTÍWSHÍSÍN KIRITIŃ...</label><br><br>
        <input type="text" name="teacher" placeholder="OQÍTÍWSHÍSÍ...................................." required><br><br>
        <button style="color: blue">QOSÍW</button>
    </form><br>
    </center>
<table>
      <thead>
        <tr>
          <th>№</th>
          <th>PÁN ATÍ</th>
          <th>PÁN MUǴALLIMI</th>
          <th>ÓZGERTIW</th>
          <th>ÓSHIRIW</th>
        </tr>
      <thead>
      <tbody>
        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <td><?php echo e($subject->name); ?></td>
          <td><?php echo e($subject->teacher); ?></td>
          <td><a href="<?php echo e(route('subject.edit', $subject->id)); ?>" style="size: 20ch">EDIT</a></td>
          <td>
            <form action="<?php echo e(route('subject.destroy', $subject->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button style="color: blue">DELETE</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    <table/>
      
    <blockquote> PÁNLER DIZIMI </blockquote>
<!-- partial -->
  
</body>
</html><?php /**PATH C:\MAMP\htdocs\Student_Semestr\resources\views/admin/subjects.blade.php ENDPATH**/ ?>