<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>students</title>
  <link rel="stylesheet" href="<?php echo e(asset("./table/style.css")); ?>">
</head>
<body>
<!-- partial:index.partial.html -->
    <center>
    <h1><a href="<?php echo e(route('student.index')); ?>">Back</a></h1>
    <h1 style="color: red">Edit student</h1>
    <form action="<?php echo e(route('student.update', $student->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label for="">1.Edit the student's full name...</label><br><br>
        <input type="text" name="fullname" value="<?php echo e($student->fullname); ?>"><br><br>
        <label for="">2.Edit the student's login...</label><br><br>
        <input type="text" name="login" value="<?php echo e($student->login); ?>"><br><br>
        <label for="">3.Edit the student's password...</label><br><br>
        <input type="text" name="password" password="<?php echo e($student->password); ?>"><br><br>
        <button style="color: blue">EDIT</button>
    </form><br>
    </center>

<!-- partial -->
  
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\VEDMOST\resources\views/admin/student_edit.blade.php ENDPATH**/ ?>