<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>students</title>
  <link rel="stylesheet" href="./table/style.css">
</head>
<body>
<!-- partial:index.partial.html -->
    <center>
    <h1><a href="<?php echo e(url('admins')); ?>">Back</a></h1>
    <h1>Student System</h1>
    <h2 style="color: red">Add students</h2>
    <form action="<?php echo e(route('student.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="">1.Write the student's full name...</label><br><br>
        <input type="text" name="fullname" placeholder="fullname..............................." required><br><br>
        <label for="">2.Write the student's login...</label><br><br>
        <input type="text" name="login" placeholder="login.................................." required><br><br>
        <label for="">3.Write the student's password...</label><br><br>
        <input type="text" name="password" placeholder="password..............................." required><br><br>
        <button style="color: blue">CREATE</button>
    </form><br>
    </center>
<table>
      <thead>
        <tr>
          <th>№</th>
          <th>Fullname</th>
          <th>Login</th>
          <th>Password</th>
          <th>Edit</th>
          <th>Delete</th>
        </tr>
      <thead>
      <tbody>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <td><?php echo e($student->fullname); ?></td>
          <td><?php echo e($student->login); ?></td>
          <td><?php echo e($student->password); ?></td>
          <td><a href="<?php echo e(route('student.edit', $student->id)); ?>" style="size: 20ch">EDIT</a></td>
          <td>
            <form action="<?php echo e(route('student.destroy', $student->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button style="color: blue">DELETE</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    <table/>
      
    <blockquote> Student System </blockquote>
<!-- partial -->
  
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\VEDMOST\resources\views/admin/students.blade.php ENDPATH**/ ?>