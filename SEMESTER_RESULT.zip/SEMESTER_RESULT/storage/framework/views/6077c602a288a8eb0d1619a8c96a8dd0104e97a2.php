<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>PANLER</title>
</head>
<body>
<!-- partial:index.partial.html -->
    <h1><a href="<?php echo e(url('admins')); ?>">IZGE</a></h1>
    <table border="5">
      <thead>
        <tr>
          <th>№</th>
          <th>Pan ati</th>
          <th>Pan mugallimi</th>
          <th>Ozgertiw</th>
          <th>Oshiriw</th>
        </tr>
      <thead>
      <tbody>
        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <td><?php echo e($subject->name); ?></td>
          <td><?php echo e($subject->teacher); ?></td>
          <td><a href="<?php echo e(route('subject.edit', $subject->id)); ?>" style="size: 20ch">EDIT</a></td>
          <td>
            <form action="<?php echo e(route('subject.destroy', $subject->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button style="color: blue">DELETE</button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    <table/>
    <h1>PANLERDI KIRITIW</h1>
    <h2 style="color: red">PANLERDI QOSIW</h2>
    <form action="<?php echo e(route('subject.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="">1.Pandi kiritin</label><br><br>
        <input type="text" name="name" required><br><br>
        <label for="">2.Pan mugallimin kiritin</label><br><br>
        <input type="text" name="teacher" required><br><br>
        <button style="color: blue">QOSÍW</button>
    </form><br>
    </center>
<!-- partial -->
  
</body>
</html><?php /**PATH C:\MAMP\htdocs\SEMESTER_RESULT\resources\views/admin/subjects.blade.php ENDPATH**/ ?>