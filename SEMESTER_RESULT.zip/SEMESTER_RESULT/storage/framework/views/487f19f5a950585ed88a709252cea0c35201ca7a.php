<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>NÁTIYJE</title>
  <link rel="stylesheet" href="<?php echo e(asset("./table/style.css")); ?>">
</head>
<body>
<!-- partial:index.partial.html -->
    <center>
    <h1><a href="<?php echo e(route('result.show', $subject[0]->id)); ?>">ARQAǴA</a></h1>
    <h1><?php echo e($student_fullname); ?> <?php echo e($subject_name); ?> páninen semestr nátiyjelerin qoyıw</h1>
    <form action="<?php echo e(route('result.store')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <label for="">1. Shegaralıq baqlaw balın kiritiń...<br>
        (Keminde 30 ball bolıwı kerek)
      </label><br><br>
      <input type="number" name="border_control" placeholder="Shegaralıq baqlaw" required><br><br>
      <label for="">2. Juwmaqlawshı baqlaw balın kiritiń...<br>
        (Keminde 30 ball bolıwı kerek)
      </label><br><br>
      <input type="number" name="final_control" placeholder="Juwmaqlawshı baqlaw" required><br><br>
      <input type="hidden" name="student_fullname" value="<?php echo e($student_fullname); ?>">
      <input type="hidden" name="subject_name" value="<?php echo e($subject_name); ?>">
      <input type="hidden" name="status" value="1">
      <button>QOSÍW</button>
    </form>
    </center>
  
<!-- partial -->
</body>
</html>
<?php /**PATH C:\MAMP\htdocs\Student_Semestr\resources\views/admin/result_create.blade.php ENDPATH**/ ?>