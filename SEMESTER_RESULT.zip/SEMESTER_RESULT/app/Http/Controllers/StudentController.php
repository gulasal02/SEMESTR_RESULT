<?php

namespace App\Http\Controllers;

use App\Http\Requests\StoreAdminRequest;
use App\Models\Student;
use App\Http\Requests\StoreStudentRequest;
use App\Http\Requests\UpdateStudentRequest;
use App\Models\Result as ModelsResult;
use App\Models\Subject;
use GuzzleHttp\Psr7\Request;
use Illuminate\Http\Request as HttpRequest;
use LDAP\Result;
use PHPUnit\Framework\MockObject\Builder\Stub;

use function Symfony\Component\String\b;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $students = Student::all()->sortBy('fullname');
        return view('admin.students', ['students' => $students]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreStudentRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreStudentRequest $request)
    {
        Student::create($request->validated());
        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function result(HttpRequest $request)
    {
        $request->validate([
            'login' => 'required',
            'password' => 'required'
        ]);
        $student = Student::where('login', $request->login)->first();
        $results = ModelsResult::get();
        $subjects = Subject::get();
        if(empty($student) OR $student->password != $request->password)
        {
            return back();    
        }
        if($student->password == $request->password)
        {
            return view('index', [
                'student' => $student,
                'results' => $results,
                'subjects' => $subjects
            ]);   
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $student = Student::find($id);
        return view('admin.student_edit', ['student' => $student]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateStudentRequest  $request
     * @param  \App\Models\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateStudentRequest $request, $id)
    {
        Student::find($id)->update($request->validated());
        return redirect('student');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Student::destroy($id);
        return back();
    }
}
