<?php

namespace App\Http\Controllers;

use App\Models\Result;
use App\Http\Requests\StoreResultRequest;
use App\Http\Requests\UpdateResultRequest;
use App\Models\Student;
use App\Models\Subject;
use Illuminate\Http\Request;



class ResultController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $subjects = Subject::all()->sortBy('name');
        return view('admin.results', ['subjects' => $subjects]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create_result(Request $request)
    {
        $student_fullname = $request->student_fullname;
        $subject_name = $request->subject_name;
        $subject = Subject::where('name', $subject_name)->get();        
        return view('admin.result_create', [
            'student_fullname' => $student_fullname,
            'subject_name' => $subject_name,
            'subject' => $subject
        ]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \App\Http\Requests\StoreResultRequest  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreResultRequest $request)
    {
        $results = Result::get();
        $subject = Subject::where('name', $request->subject_name)->get();
        $result = Result::where('student_fullname', $request->student_fullname)->first();
        if(empty($result) OR $result->subject_name != trim($request->subject_name))
        {
            Result::create([
                'student_fullname' => $request->student_fullname,
                'subject_name' => $request->subject_name,
                'status' => $request->status,
                'border_control' => $request->border_control,
                'final_control' => $request->final_control,
                'result' => $request->border_control+$request->final_control
            ]);
            return view('admin.result_created', [
                'student_fullname' => $request->student_fullname,
                'subject_name' => $request->subject_name,
                'subject' => $subject
            ]);
        }
        if($result->subject_name == trim($request->subject_name))
        {
            return view('admin.already_created', ['subject' => $subject]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Result  $result
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $subject = Subject::find($id);
        $students = Student::all()->sortBy('fullname');
        $results = Result::get();
        return view('admin.result_add', ['subject' => $subject, 'students' => $students, 'results' => $results]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Result  $result
     * @return \Illuminate\Http\Response
     */
    public function edit_result(Request $request)
    {
        $subject = Subject::where('name', $request->subject_name)->get();
        $result = Result::find($request->id);
        return view('admin.result_edit', [
            'student_fullname' => $request->student_fullname,
            'subject_name' => $request->subject_name,
            'subject' => $subject,
            'result' => $result
        ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \App\Http\Requests\UpdateResultRequest  $request
     * @param  \App\Models\Result  $result
     * @return \Illuminate\Http\Response
     */
    public function update(UpdateResultRequest $request, $id)
    {
        $subject = Subject::where('name', $request->subject_name)->get();
        Result::find($id)->update([
            'student_fullname' => $request->student_fullname,
            'subject_name' => $request->subject_name,
            'status' => $request->status,
            'border_control' => $request->border_control,
            'final_control' => $request->final_control,
            'result' => $request->border_control+$request->final_control
        ]);
        return view('admin.result_updated', ['subject' => $subject]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Result  $result
     * @return \Illuminate\Http\Response
     */
    public function destroy(Result $result)
    {
        //
    }
}
